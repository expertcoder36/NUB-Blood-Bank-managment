# NUB Blood-Bank-&-Donation-Management-System

Blood Bank Donation System is a php based web project with both admin and user layouts.

# Installation

1. Install XAMPP or WAMPP.

2. Open XAMPP Control panal and start [apache] and [mysql] .
     
3. Extract files in C:\xampp\htdocs.

4. Open link localhost/phpmyadmin

5. Click on new at side navbar.

6. Give a database name as (blood_bank_database) hit on create button.

7. After creating database name click on import.

8. Browse the file in directory[BDMS/sql/blood_bank_database.sql].

9. After importing successfully.

10. Open any browser and type http://localhost/BDMS/home.php to open User layout.
     
# Admin Panel
   Open any browser and type http://localhost/BDMS/admin/login.php to open Admin Login Panel.
   
   Enter Below Credentials to login to the Admin Panel.<br>
   <b> Username = </b> nub <br>
   <b>Password = </b> nub123 <br>
   
Thanks!
   
